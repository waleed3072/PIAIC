# AI-Q3-learning-resources
AIC Quarter 3 Learning and Practice Resources

https://colab.research.google.com/drive/13NaDXNl_ABH0xuBoCtk6NacJlPOd2HL5
